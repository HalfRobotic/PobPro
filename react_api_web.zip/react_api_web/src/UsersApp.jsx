import { useEffect, useState } from "react"
import { AfegirUser } from './components/AfegirUser.jsx'
import './components/AfegirUser.jsx'



export const UsersApp = () => {
  const [UsersList, setUsersList] = useState([])

  const addUser = (itemRebut) =>{

    if(itemRebut < 1)return
    const itemObject = {
      id:UsersList.length +1,
      User:itemRebut
      
    }
    setList([...  UsersList, itemObject])
  }
  const fetchUsers = async() => {
    try{
        const resposta = await fetch('https://jsonplaceholder.typicode.com/users')
        const dades = await resposta.json()
        setUsersList(dades)
        console.log("Usuaris carregats")
    }
    catch(error){ 
        console.log(error)
    }
  }
  useEffect(()=> {fetchUsers()},[])
    return (
    <>
    <h1>Llistat d'usuaris</h1>  
    <AfegirUser addElement={addUser}></AfegirUser>
    <ul>
        {UsersList.map(item => <li key={item.id}>{item.name}</li>)}
    </ul>
    </>
    )
}
