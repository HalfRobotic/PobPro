import { useState } from 'react'
import './components/AfegirTasca.jsx'
import { AfegirTasca } from './components/AfegirTasca.jsx'

const Item = ({tasca,Doit})=>{
  return(
    <li>
      {tasca}
      { Doit ?'😇':'😈'}  
    </li>
    

  )
}

export const LlistatApp = ({}) => {
  let llistatToDo = [
    {id:0,tasca:'Tasca 1',Doit:true},
    {id:1,tasca:'Tasca sense',Doit:false},
    {id:2,tasca:'Tasca feta',Doit:true},
  ]
  const [list, setList] = useState(llistatToDo)

  const addTask = (itemRebut) =>{
    
    if(itemRebut < 1)return
    const itemObject = {
      id:list.length +1,
      tasca:itemRebut,
      Doit:false
    }
    setList([...list, itemObject])
  }
  return (
    <>
      <h1>ToDo List:</h1>
      <AfegirTasca addElement={addTask}></AfegirTasca>
      <ol>
      {list.map(x => <Item key={x.id} tasca={x.tasca} Doit ={x.Doit}></Item>)}
      </ol>
    </>
    )
}
