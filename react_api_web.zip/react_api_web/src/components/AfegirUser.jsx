import { useState } from "react"


export const AfegirUser = ({addElement}) => {
    const [inputValue, setInputValue] = useState('')

    const onInputChange= (event)=>{
        //console.log(event)
        setInputValue(event.target.value)
    }
    const onSubmitInput = (event) =>{
        event.preventDefault()
        console.log("Enviat")
        addElement(inputValue)
        setInputValue("")
    }
    return (
        <form onSubmit={onSubmitInput}>

        <input
        id="inputAddUser"
        type="text"
        placeholder="Add new User"
        value={inputValue}
        onChange={onInputChange}
        >
        </input>
        </form>
    )
}
