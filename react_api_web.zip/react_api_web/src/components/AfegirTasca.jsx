import { useState } from "react"


export const AfegirTasca = ({addElement}) => {
    const [inputValue, setInputValue] = useState('')

    const onInputChange= (event)=>{
        //console.log(event)
        setInputValue(event.target.value)
    }
    const onSubmitInput = (event) =>{
        event.preventDefault()
        //console.log("Enviat")
        addElement(inputValue)
    }
    return (
        <form onSubmit={onSubmitInput}>

        <input
        id="inputAddTask"
        type="text"
        placeholder="Add new taks To Do"
        value={inputValue}
        onChange={onInputChange}
        >
        </input>
        </form>
    )
}
